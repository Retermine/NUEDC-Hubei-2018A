/*
 * delay.h
 *
 *  Created on: 2017��11��12��
 *      Author: hxflq
 */

#ifndef SRC_LCD_DELAY_H_
#define SRC_LCD_DELAY_H_


#include "xil_types.h"
#include "xil_assert.h"

void delay_ms(u16 );
void delay_us(u16 );



#endif /* SRC_LCD_DELAY_H_ */
